
import random
import csv

# List of generic names
generic_names = [
    "John", "Emma", "Michael", "Sophia", "William", "Olivia", "James", "Ava", "Benjamin", "Isabella","Nimisha","Arjun","Aswin","Adwaid""Udith","Jithin","Rohith","Drishya","Sinan","Ganga",
    "Jyothika","Dilna","Ashwathy","Anand","Arjit","Ajit","Adarsh","Kiran","Navaneeth","Goutham","Gokul","Aashiyan","Ashik","Nihal",
    "Imthiyaz","Hareesh","Ridha","Vismaya","Zuhara","Sandra","Fathima","Fahmida","Farook","Aarshikha",
    "Jacob", "Mia", "Daniel", "Charlotte", "Elijah", "Amelia", "Matthew", "Harper", "David", "Evelyn"
    # Add more names as needed
]

# List of responses
responses = []

# Generating 2000 random responses with generic names
for student_id in range(1, 801):
    name = random.choice(generic_names)
    attributes = []
    attributes.append(random.choice(["No", "Yes"]))  # Differently Abled
    attributes.append(random.choice(["Yes", "No"]))  # Participate in Extra Curricular
    attributes.append(random.choice(["Yes", "No"]))  # Drink Enough Water
    attributes.append(random.choice(["Yes", "No"]))  # Eat Nutritious Food
    attributes.append(random.choice(["Yes", "No"]))  # Exercise
    attributes.append(random.choice(["Yes", "No"]))  # Sports Medals
    attributes.append(random.choice(["Yes", "No"]))  # Health Issues
    attributes.append(random.choice(["Yes", "No"]))  # Dull in Classroom
    attributes.append(random.choice(["Yes", "No"]))  # Hygienic Person
    attributes.append(random.choice(["Yes", "No"]))  # Preventive Measures
    attributes.append(random.choice(["Yes", "No"]))  # Get Ill Often

    positive_attributes = ["Participate in Extra Curricular", "Drink Enough Water",
                           "Eat Nutritious Food", "Exercise", "Sports Medals",
                           "Hygienic Person", "Preventive Measures"]
    negative_attributes = ["Differently Abled", "Health Issues", "Dull in Classroom", "Get Ill Often"]

    positive_count1 = sum(attributes == "Yes" for attributes in positive_attributes)
    positive_count2 = sum(attributes == "No" for attributes in negative_attributes)
    negative_count1 = sum(attributes == "Yes" for attributes in negative_attributes)
    negative_count2 = sum(attributes == "No" for attributes in positive_attributes)


    positive_count = positive_count1 + positive_count2
    negative_count = negative_count1 + negative_count2
    # Assigning performance based on attribute counts
    if positive_count > negative_count:
        performance = "High"
    elif negative_count > positive_count:
        performance = "Low"
    else:
        performance = random.choices(["High", "Medium", "Low"], weights=[0.3, 0.4, 0.3])[0]

    responses.append([
        student_id, name, *attributes, performance
    ])

# Save the dataset as a CSV file
filename = "student_dataset.csv"
header = ["Student ID", "Name", "Differently Abled", "Participate in Extra Curricular", "Drink Enough Water",
          "Eat Nutritious Food", "Exercise", "Sports Medals", "Health Issues", "Dull in Classroom",
          "Hygienic Person", "Preventive Measures", "Get Ill Often", "Performance"]

with open(filename, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(header)
    writer.writerows(responses)

print(f"Dataset with {len(responses)} students has been saved as '{filename}'.")
