import pickle
def predict_kn(row):
    filename = 'knn_model.sav'
    model = pickle.load(open(filename, 'rb'))
    predicted_value = model.predict([row])
    return predicted_value[0]



qq=[1,1,0,1,0,1,0,1,1,1,0]
print(predict_kn(qq))


