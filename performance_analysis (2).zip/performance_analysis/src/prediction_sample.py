import pickle

import pandas as pd
from sklearn.model_selection import train_test_split

data= pd.read_csv("dataset.csv")



xx=[]
yy=[]

print(data.head())
for i in range(0,len(data['Performance'])):
    row=[]
    row.append(data['Differently Abled'][i].replace(" ",""))
    row.append(data['Participate in Extra Curricular'][i].replace(" ",""))
    row.append(data['Drink Enough Water'][i].replace(" ",""))
    row.append(data['Eat Nutritious Food'][i].replace(" ", ""))
    row.append(data['Exercise'][i].replace(" ", ""))
    row.append(data['Sports Medals'][i].replace(" ", ""))
    row.append(data['Health Issues'][i].replace(" ", ""))
    row.append(data['Dull in Classroom'][i].replace(" ", ""))
    row.append(data['Hygienic Person'][i].replace(" ", ""))
    row.append(data['Preventive Measures'][i].replace(" ", ""))
    row.append(data['Get Ill Often'][i].replace(" ",""))
    yy.append(data['Performance'][i].replace(" ",""))
    xx.append(row)


# print(yy)
# print(xx)

disy=['High', 'Medium', 'Low']
f=["no","yes"]


x=[]
y=[]
for i in range(0,len(xx)):
    y.append(disy.index(yy[i]))
    row=[]
    for ii in xx[i]:
        row.append(f.index(ii.lower()))
    x.append(row)

print(x)
print(y)

# from sklearn.model_selection import train_test_split
# X_train, X_test, y_train, y_test = train_test_split(x,y, test_size = 0.20)
#
# from sklearn.neighbors import KNeighborsClassifier
#
# knn = KNeighborsClassifier(n_neighbors=1)
#
# knn.fit(X_train, y_train)
# pred = knn.predict(X_test)



from sklearn.neighbors import KNeighborsClassifier
X_train, X_test, t_train, t_test = train_test_split(
	x, y, test_size=0.3, shuffle=True, random_state=1)

# model = DecisionTreeClassifier(criterion = "gini",
#             random_state = 100,max_depth=10, min_samples_leaf=10)
# model = model.fit(X_train, t_train)

# model = SVC(C= .1, kernel='linear', gamma= 1)
# model.fit(X_train, t_train)
model= KNeighborsClassifier(n_neighbors=1)
model.fit(x, y)
#
filename = 'knn_model.sav'
pickle.dump(model, open(filename, 'wb'))

# load the model
model = pickle.load(open(filename, 'rb'))

# from sklearn.neighbors import KNeighborsClassifier
#
# model = KNeighborsClassifier(n_neighbors=3)
#
# model.fit(X_train, t_train)

predicted_value = model.predict(X_test)
print(predicted_value)

match = 0
UnMatch = 0

for i in range(len(predicted_value)):
	if predicted_value[i] == t_test[i]:
		match += 1
	else:
		UnMatch += 1

accuracy = match/len(predicted_value)
print("Accuracy is: ", accuracy*100)

from sklearn.metrics import classification_report, confusion_matrix

print(confusion_matrix(t_test, predicted_value))

print(classification_report(t_test, predicted_value))
