from flask import *

from src.dbconnectionnew import *

app=Flask(__name__)
app.secret_key="dfghjkl"


@app.route('/')
def login():
    return render_template('index.html')

@app.route('/login_post',methods=['post'])
def login_post():
    uname=request.form['username']
    psw=request.form['password']
    q="SELECT * FROM `login` WHERE `username`=%s AND `password`=%s"
    val=(uname,psw)
    res=selectone(q,val)
    if res is None:
        return '''<script>alert("inavlid user name or password");window.location='/'</script>'''
    elif res['type']=='admin':
        return '''<script>alert("Welcome admin");window.location='/admin_home'</script>'''
    elif res['type']=='staff':
        session['lid']=res['lid']
        return '''<script>alert("Welcome staff");window.location='/staff_home'</script>'''
    else:
        return '''<script>alert("Invalid!!!!");window.location='/'</script>'''

#=====================================ADMIN=========================================================================

@app.route('/admin_home')
def admin_home():
    return render_template('admin/adminhome.html')


@app.route('/managecource')
def managecource():
    qry="SELECT * FROM `course`"
    res=selectall(qry)
    return render_template('admin/managecource.html',val=res)

@app.route('/Add_Course')
def Add_Course():
    return render_template('admin/Add Course.html')

@app.route('/Add_Course_post',methods=['post'])
def Add_Course_post():
    course = request.form['textfield']
    details = request.form['textarea2']
    q="INSERT INTO `course` VALUES (NULL,%s,%s)"
    val=(course,details)
    iud(q,val)
    return '''<script>alert("Added successfully");window.location='/managecource'</script>'''

@app.route('/delete_course')
def delete_course():
    id=request.args.get('id')
    qry="DELETE FROM `course` WHERE `course_id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location='/managecource'</script>'''

@app.route('/delete_sub')
def delete_sub():
    id=request.args.get('id')
    qry="DELETE FROM `subject` WHERE `subject_id`=%s"
    iud(qry,id)
    return '''<script>alert("Deleted successfully");window.location='/managesubject'</script>'''

@app.route('/delete_noti')
def delete_noti():
    id=request.args.get('id')
    qry="DELETE FROM `notification` WHERE `notification_id`=%s"
    iud(qry,id)

    return '''<script>alert("Deleted successfully");window.location='/Send_notification'</script>'''



@app.route('/delete_Allocation')
def delete_Allocation():
    id=request.args.get('id')
    qry="DELETE FROM `allocate` WHERE `allocate_id`=%s"
    iud(qry,id)

    return '''<script>alert("Deleted successfully");window.location='/Allocate_subject_to_staff'</script>'''


@app.route('/delete_staff')
def delete_staff():
    id=request.args.get('id')
    qry="DELETE FROM `login` WHERE `lid`=%s"
    iud(qry,id)
    qry1="DELETE FROM `staff` WHERE `lid`=%s"
    iud(qry1,id)
    return '''<script>alert("Deleted successfully");window.location='/manage_staff'</script>'''



@app.route('/manage_staff')
def manage_staff():
    qry="SELECT `staff`.*,`course`.`course` AS ccourse FROM `staff` JOIN `course` ON `course`.`course_id`=`staff`.`course`"
    res=selectall(qry)
    return render_template('admin/manage staff.html',val=res)

@app.route('/edit_staff')
def edit_staff():
    id=request.args.get('id')
    session['sid']=id
    qry="SELECT * FROM `staff` where lid=%s"
    res=selectone(qry,id)
    q="SELECT * FROM course"
    res1=selectall(q)
    return render_template('admin/edit staff.html',val=res,v=res1)

@app.route('/Add_Staff')
def Add_Staff():
    qry="SELECT * FROM `course`"
    res=selectall(qry)
    return render_template('admin/Add Staff.html',val=res)

@app.route('/Add_Staff_post',methods=['post'])
def Add_Staff_post():
    first_name = request.form['textfield']
    last_name = request.form['textfield2']
    gender = request.form['radiobutton']
    phone = request.form['textfield4']
    email = request.form['textfield5']
    course = request.form['select']
    username = request.form['textfield7']
    password = request.form['textfield8']
    qry1="INSERT INTO `login` VALUES(NULL,%s,%s,'staff')"
    val1=(username,password)
    id=iud(qry1,val1)

    q="INSERT INTO `staff` VALUES (NULL,%s,%s,%s,%s,%s,%s,%s)"
    val=(str(id),first_name,last_name,gender,phone,email,course)
    iud(q,val)
    return '''<script>alert("Added successfully");window.location='/manage_staff'</script>'''

@app.route('/managesubject')
def managesubject():
    qry = "SELECT * FROM `course`"
    res = selectall(qry)

    return render_template('admin/managesubject.html',val=res)
@app.route('/managesubject1',methods=['post'])
def managesubject1():
    c=request.form['select']
    qry = "SELECT * FROM `course`"
    res = selectall(qry)
    qry1="SELECT * FROM `subject` WHERE `course_id`=%s"
    res1=selectall2(qry1,c)

    return render_template('admin/managesubject.html',val=res,data=res1)


@app.route('/Add_Subject')
def Add_Subject():
    q="select * from course"
    res=selectall(q)
    return render_template('admin/Add Subject.html',data=res)

@app.route('/Add_Subject_post',methods=['post'])
def Add_Subject_post():
    course = request.form['select']
    subject = request.form['textfield']
    q="INSERT INTO `subject` VALUES(NULL,%s,%s)"
    val=(course,subject)
    iud(q,val)
    return '''<script>alert("Added successfully");window.location='/managesubject'</script>'''

@app.route('/edit_Staff_post',methods=['post'])
def edit_Staff_post():
    first_name = request.form['textfield']
    last_name = request.form['textfield2']
    gender = request.form['radiobutton']
    phone = request.form['textfield4']
    email = request.form['textfield5']
    course = request.form['select']
    q="UPDATE `staff` set fname=%s,lname=%s, gender=%s, phone=%s, email=%s, course=%s  where lid=%s"
    val=(first_name,last_name,gender,phone,email,course, session['sid'])
    iud(q,val)
    return '''<script>alert("Edited successfully");window.location='/manage_staff'</script>'''

@app.route('/Complaints')
def Complaints():
    qry="SELECT * FROM `complaint` JOIN `student` ON `student`.`lid`=`complaint`.`lid` WHERE `complaint`.`reply`='pending'"
    res=selectall(qry)
    return render_template('admin/Complaints.html',val=res)

@app.route('/send_reply')
def send_reply():
    id=request.args.get('id')
    session['CID']=id
    return render_template('admin/send_reply.html')

@app.route('/send_reply1',methods=['post'])
def send_reply1():
    reply = request.form['textfield']
    qry="UPDATE `complaint` SET `reply`=%s WHERE `complaint_id`=%s"
    val=(reply,session['CID'])
    iud(qry,val)
    return '''<script>alert("SEND successfully");window.location='/Complaints'</script>'''





@app.route('/Send_notification')
def Send_notification():
    qry= "SELECT * FROM `notification` "
    res= selectall(qry)

    return render_template('admin/Send notification.html',val=res)

@app.route('/send_noti1',methods=['post'])
def send_noti1():
    noti=request.form['textfield']
    qry="INSERT INTO `notification` VALUES(NULL,%s,CURDATE())"
    val=(noti)
    iud(qry,val)
    return '''<script>alert("SEND successfully");window.location='/Send_notification'</script>'''


@app.route('/send_noti')
def send_noti():
    return render_template('admin/send_noti.html')


@app.route('/Allocate_subject_to_staff')
def Allocate_subject_to_staff():
    qry="SELECT `staff`.`fname`,`staff`.`lname` ,`allocate`.`allocate_id`,`subject`.`subject` FROM `staff` JOIN `allocate` ON `staff`.`lid`=`allocate`.`staff_id` JOIN `subject` ON `subject`.`subject_id`=`allocate`.`subject_id`"
    res=selectall(qry)
    return render_template('admin/Allocate subject to staff.html',val=res)

@app.route('/Allocate',methods=['post'])
def Allocate():
    qry="SELECT * FROM `subject`"
    res=selectall(qry)
    qry1="SELECT * FROM `staff`"
    res1=selectall(qry1)
    return render_template('admin/Allocate.html',val=res,val1=res1)

@app.route('/Allocate1',methods=['post'])
def Allocate1():
    staff = request.form['select']
    sub = request.form['select2']

    qry = "INSERT INTO `allocate` VALUES(NULL,%s,%s)"
    val = (staff,sub)
    iud(qry, val)
    return '''<script>alert("Added successfully");window.location='/Allocate_subject_to_staff'</script>'''




@app.route('/performance')
def performance():
    qry1="SELECT * FROM `course`"
    res= selectall(qry1)
    return render_template('admin/performance.html',val=res)

@app.route('/performance1',methods=['post'])
def performance1():
    cou = request.form['select']
    sem = request.form['select2']
    q="SELECT * FROM `student` JOIN `result` ON `result`.`lid`=`student`.`lid`  WHERE `course_id`=%s AND `semester`=%s"
    r=selectall2(q,(cou,sem))
    qry1 = "SELECT * FROM `course`"
    res = selectall(qry1)
    return render_template('admin/performance.html',data=r,val=res)


@app.route('/Add_Complaints_post',methods=['post'])
def Add_Complaints_post():
    Complaints = request.form['textfield']
    return render_template('admin/Add Course.html')

#==================================================================STAFF===============================================





@app.route('/staff_home')
def staff_home():
    return render_template('staff/staff home.html')

@app.route('/manageattendance')
def manageattendance():
    qry="  SELECT `student`.`fname`,`lname` ,`attendence`.`attence` FROM `student` JOIN `attendence`ON`student`.`lid`=`attendence`.`studid` JOIN`allocate` ON  `attendence`.`subid`=`allocate`.`subject_id` WHERE `allocate`.`staff_id`=%s GROUP BY `attendence`.`id`"
    res=selectall2(qry,session['lid'])

    return render_template('staff/manage attendance.html',val=res)

@app.route('/Add_attendance',methods=['post'])
def Add_attendence():
    qry="SELECT * FROM `student` JOIN `course`ON `student`.`course_id`=`course`.`course_id` JOIN `staff` ON `course`.`course_id`=`staff`.`course` WHERE `staff`.`lid`=%s"
    res = selectall2(qry, session['lid'])

    return render_template('staff/add attendance.html',val=res)


@app.route('/Add_attendance1',methods=['post'])
def Add_attendance1():
    att=request.form['textfield2']
    stu=request.form['select']

    # qry="SELECT `subject`.`subject_id`,`subject` FROM `subject` JOIN `allocate` ON `allocate`.`subject_id`=`subject`.`subject_id` WHERE `allocate`.`staff_id`=%s"
    # res=selectone(qry,session['lid'])
    # session['Sub_id']=res['subject_id']
    qry1="INSERT INTO `attendence` VALUES(NULL,%s,%s,%s)"
    val1=(session['Sub_id'],stu,att)
    iud(qry1,val1)
    return '''<script>alert("Added successfully");window.location='/manageattendance'</script>'''


@app.route('/managemarks')
def managemarks():
    qry="SELECT `student`.`fname`,`lname` ,`marks`.`mark` FROM `student` JOIN `marks`ON`student`.`lid`=`marks`.`studentid` JOIN`allocate` ON  `marks`.`subid`=`allocate`.`subject_id` WHERE `allocate`.`staff_id`=%s GROUP BY `marks`.`id`"
    res=selectall2(qry,session['lid'])

    return render_template('staff/manage marks.html',val=res)

@app.route('/Add_marks',methods=['post'])
def Add_marks():
    qry="SELECT * FROM `student` JOIN `course`ON `student`.`course_id`=`course`.`course_id` JOIN `staff` ON `course`.`course_id`=`staff`.`course` WHERE `staff`.`lid`=%s"
    res=selectall2(qry,session['lid'])
    return render_template('staff/add marks.html',val=res)
@app.route('/Add_marks1',methods=['post'])
def Add_marks1():
    mark=request.form['textfield2']
    stu=request.form['select']

    qry="SELECT `subject`.`subject_id`,`subject` FROM `subject` JOIN `allocate` ON `allocate`.`subject_id`=`subject`.`subject_id` WHERE `allocate`.`staff_id`=%s"
    res=selectone(qry,session['lid'])
    session['Sub_id']=res['subject_id']
    qry1="INSERT INTO `marks` VALUES(NULL,%s,%s,%s)"
    val1=(stu,session['Sub_id'],mark)
    iud(qry1,val1)
    return '''<script>alert("Added successfully");window.location='/managemarks'</script>'''




@app.route('/managestudent')
def managestudent():
    qry = "SELECT `student`.*,`course`.`course` AS ccourse FROM `student` JOIN `course` ON `course`.`course_id`=`student`.`course_id`"
    res=selectall(qry)
    return render_template('staff/manage student.html',val=res)

@app.route('/Add_student')
def Add_student():
    q="SELECT * FROM `course`"
    res=selectall(q)
    return render_template('staff/add student.html',val=res)

@app.route('/view_assigned_subjects')
def view_assigned_subjects():
    qry="SELECT * FROM course"
    res=selectall(qry)
    return render_template('staff/view assigned subjects.html',val=res)

@app.route('/view_assigned_subjectssearch',methods=['get','post'])
def view_assigned_subjectssearch():
    course=request.form['select']
    print(course,"JJJJJJJJJJJJJJJJJ")
    qry="SELECT * FROM course"
    res=selectall(qry)
    qr="SELECT * FROM `subject` WHERE `course_id`=%s"
    # qr="SELECT * FROM `allocate` JOIN SUBJECT ON allocate.subject_id=subject.subject_id WHERE subject.course_id=%s AND `allocate`.staff_id=%s"
    val=(course)
    re=selectall2(qr,val)
    print(re)
    return render_template('staff/view assigned subjects.html',val=res,va=re)

@app.route('/view_notification')
def view_notification():
    qry="SELECT * FROM`notification`"
    res=selectall(qry)
    return render_template('staff/view notification.html',val=res)

@app.route('/view_student_performance')
def view_student_performance():
    qry1="SELECT * FROM `course`"
    res= selectall(qry1)
    return render_template('staff/view student performance.html',val=res)

@app.route('/view_student_performance1',methods=['post'])
def view_student_performance1():
    cou = request.form['select']
    sem = request.form['select2']
    q="SELECT * FROM `student` JOIN `result` ON `result`.`lid`=`student`.`lid`  WHERE `course_id`=%s AND `semester`=%s"
    r=selectall2(q,(cou,sem))
    qry1 = "SELECT * FROM `course`"
    res = selectall(qry1)
    return render_template('staff/view student performance.html',data=r,val=res)





@app.route('/add_student_post',methods=['post'])
def add_student_post():
    first_name = request.form['textfield']
    last_name = request.form['textfield2']
    gender = request.form['radiobutton']
    place = request.form['textfield4']
    course = request.form['select']
    semester = request.form['textfield6']
    username = request.form['textfield7']
    password = request.form['textfield8']
    qry1="INSERT INTO `login` VALUES(NULL,%s,%s,'student')"
    val1=(username,password)
    id=iud(qry1,val1)

    q="INSERT INTO `student` VALUES (NULL,%s,%s,%s,%s,%s,%s,%s)"
    val=(str(id),first_name,last_name,gender,place, course, semester)
    iud(q,val)
    return '''<script>alert("Added successfully");window.location='/managestudent'</script>'''

@app.route('/delete_student')
def delete_student():
    id=request.args.get('id')
    qry="DELETE FROM `login` WHERE `lid`=%s"
    iud(qry,id)
    qry1="DELETE FROM `student` WHERE `lid`=%s"
    iud(qry1,id)
    return '''<script>alert("Deleted successfully");window.location='/managestudent'</script>'''



@app.route('/edit_student')
def edit_student():
    id=request.args.get('id')
    session['sid']=id
    qry="SELECT * FROM `student` where lid=%s"
    res=selectone(qry,id)
    q="SELECT * FROM course"
    res1=selectall(q)
    return render_template('staff/edit student.html',val=res,v=res1)

@app.route('/edit_student_post',methods=['post'])
def edit_student_post():
    First_name = request.form['textfield']
    Last_name = request.form['textfield2']
    Gender = request.form['radiobutton']
    Place = request.form['textfield4']
    Course = request.form['select']
    Semester = request.form['textfield6']
    q="UPDATE `student` set fname=%s,lname=%s, gender=%s, place=%s, course_id=%s,semester=%s  where lid=%s"
    val=(First_name,Last_name,Gender,Place,Course,Semester, session['sid'])
    iud(q,val)
    return '''<script>alert("Edited successfully");window.location='/managestudent'</script>'''





app.run(debug=True)
