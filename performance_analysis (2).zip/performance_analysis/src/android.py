from flask import *

from src.dbconnectionnew import *
from src.pre import predict_kn

app=Flask(__name__)

@app.route('/login_post',methods=['post'])
def login_post():
    print(request.form)
    uname=request.form['uname']
    psw=request.form['pass']
    q="SELECT * FROM `login` WHERE `username`=%s AND `password`=%s"
    val=(uname,psw)
    res=selectone(q,val)
    if res is None:
        return jsonify({'task': 'invalid'})
    else:
        id=res['lid']
        return jsonify({'task':'valid',"id" : id})

@app.route('/Send_Complaints',methods=['post'])
def Send_Complaints():
    print(request.form)
    complaints=request.form['Complaints']
    lid = request.form['lid']

    qry="INSERT INTO `complaint` VALUES(NULL,%s,%s,CURDATE(),'pending')"
    val=(lid,complaints)
    iud(qry,val)
    return jsonify({'task': 'valid'})

@app.route('/view_complaints',methods=['post'])
def view_complaints():
    lid=request.form['lid']
    print(lid)
    qry=" SELECT * FROM `complaint` WHERE `lid`=%s"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)

@app.route('/view_att',methods=['post'])
def view_att():
    lid=request.form['lid']
    print(lid)

    qry="SELECT `subject`.`subject`,`attendence`.`attence` FROM `attendence` JOIN `subject` ON `subject`.`subject_id`=`attendence`.`subid` WHERE `attendence`.`studid`=%s"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)

@app.route('/view_marks',methods=['post'])
def view_marks():
    lid=request.form['lid']
    qry="SELECT `marks`.`mark`,`subject`.`subject` FROM `subject` JOIN `marks` ON `marks`.`subid`=`subject`.`subject_id` WHERE `marks`.`studentid`=%s"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)

@app.route('/view_subject',methods=['post'])
def view_subject():
    lid=request.form['lid']
    qry="SELECT `subject`.* FROM `course` JOIN `subject` ON `subject`.`course_id`=`course`.`course_id`  JOIN `student` ON `student`.`course_id`=`course`.`course_id` WHERE `student`.`lid`=%s"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)


@app.route('/perfomance',methods=['post'])
def perfomance():
    lid=request.form['lid']
    print(request.form)
    que=[]
    q1=request.form['q1']
    que.append(int(q1))
    q2=request.form['q2']
    que.append(int(q2))
    q3 = request.form['q3']
    que.append(int(q3))
    q4 = request.form['q4']
    que.append(int(q4))
    q5 = request.form['q5']
    que.append(int(q5))
    q6 = request.form['q6']
    que.append(int(q6))
    q7 = request.form['q7']
    que.append(int(q7))
    q8 = request.form['q8']
    que.append(int(q8))
    q9 = request.form['q9']
    que.append(int(q9))
    q10 = request.form['q10']
    que.append(int(q10))
    q11 = request.form['q11']
    que.append(int(q11))
    res=predict_kn(que)
    print(res)
    if res==0:
        result="High"
    elif res==1:
        result="Medium"
    elif res==2:
        result="Low"
    print("result is ",result)
    q="insert into result values(null,%s,%s)"
    val=(lid,result)
    iud(q,val)
    return jsonify({"task":"success","result":result})

app.run(debug=True,host='0.0.0.0')