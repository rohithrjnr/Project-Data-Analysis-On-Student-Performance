/*
SQLyog Community v13.0.1 (64 bit)
MySQL - 5.5.20-log : Database - performance analysis
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`performance analysis` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `performance analysis`;

/*Table structure for table `allocate` */

DROP TABLE IF EXISTS `allocate`;

CREATE TABLE `allocate` (
  `allocate_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`allocate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `allocate` */

insert  into `allocate`(`allocate_id`,`staff_id`,`subject_id`) values 
(4,16,8),
(5,18,10);

/*Table structure for table `attendence` */

DROP TABLE IF EXISTS `attendence`;

CREATE TABLE `attendence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subid` int(11) DEFAULT NULL,
  `studid` int(11) DEFAULT NULL,
  `attence` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `attendence` */

insert  into `attendence`(`id`,`subid`,`studid`,`attence`) values 
(1,1,11,'90'),
(2,1,11,'90'),
(3,1,11,'90'),
(4,8,19,'20'),
(5,8,17,'90');

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `complaint` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `reply` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`complaint_id`,`lid`,`complaint`,`date`,`reply`) values 
(1,111,'dfvfbghhg','2023-04-14','sdada'),
(2,11,'fff','2023-05-14','ok'),
(3,11,'hrllo','2023-05-14','ok'),
(4,11,'ytref','2023-05-14','aa'),
(5,11,'ttt','2023-05-14','poda'),
(6,17,'hi','2023-05-15','ok'),
(7,17,'','2023-05-20','sdaa');

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course` varchar(30) DEFAULT NULL,
  `details` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `course` */

insert  into `course`(`course_id`,`course`,`details`) values 
(9,'Information technology','it'),
(10,'Computer Science','cse'),
(11,'Electrical and Electronics Eng','EEE '),
(12,'Electronics and Communication','ECE'),
(13,'Civil Engineering','CE'),
(15,'mechanial engineering','me');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`lid`,`username`,`password`,`type`) values 
(1,'admin','admin','admin'),
(4,'ertete','123','staff'),
(6,'','','student'),
(7,'','','student'),
(8,'asndjajasdadadaasdasdas','aswinbhaskaran1245','student'),
(9,'dsdsddds','dssddsdsds','student'),
(10,'','','student'),
(11,'ss','ss','student'),
(12,'','','student'),
(14,'aswin','k','student'),
(15,'','','student'),
(16,'praveensir','Praveen@123','staff'),
(17,'aswink','Aswin@123','student'),
(18,'sreerajsir','Sreeraj@123','staff'),
(19,'nimishak','Nimisha@123','student'),
(20,'manojkjayan','Manjoj@123','student'),
(21,'naveena','Naveena@123','staff');

/*Table structure for table `marks` */

DROP TABLE IF EXISTS `marks`;

CREATE TABLE `marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT NULL,
  `subid` int(11) DEFAULT NULL,
  `mark` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `marks` */

insert  into `marks`(`id`,`studentid`,`subid`,`mark`) values 
(1,11,1,'29'),
(2,11,1,'50'),
(3,11,1,'000'),
(4,19,8,'80'),
(5,17,8,'0');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `notification` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `notification` */

insert  into `notification`(`notification_id`,`notification`,`date`) values 
(3,'nimisha','2023-05-15');

/*Table structure for table `result` */

DROP TABLE IF EXISTS `result`;

CREATE TABLE `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `result` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `result` */

insert  into `result`(`id`,`lid`,`result`) values 
(1,11,'Low'),
(2,17,'Medium'),
(3,17,'Low'),
(4,17,'Low'),
(5,17,'Medium'),
(6,17,'High'),
(7,17,'Medium'),
(8,17,'Low'),
(9,17,'Low'),
(10,17,'Low'),
(11,17,'Low'),
(12,17,'Medium'),
(13,17,'Medium'),
(14,17,'Medium'),
(15,17,'Low'),
(16,17,'Medium'),
(17,17,'High'),
(18,17,'High'),
(19,17,'High'),
(20,17,'High'),
(21,17,'Medium'),
(22,17,'Medium'),
(23,17,'High'),
(24,17,'High'),
(25,17,'Low'),
(26,17,'High');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `course` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`staff_id`,`lid`,`fname`,`lname`,`gender`,`phone`,`email`,`course`) values 
(3,4,'ROHITH','RAJ','male',9605860539,'rohithrjnr43@gmail.com','1'),
(4,16,'Praveen k ','Wilson','male',9445967834,'praveenkwilson@gmail.com','9'),
(5,18,'Sreeraj ','S','male',6713123122,'sreeraj@gmail.com','10'),
(6,21,'Naveena ','Miss','female',9897908237,'naveenaoar@sasasd.com','11');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `std_id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `place` varchar(30) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `semester` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`std_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`std_id`,`lid`,`fname`,`lname`,`gender`,`place`,`course_id`,`semester`) values 
(0,111,'hnsdhgcs','dfvd',NULL,NULL,NULL,NULL),
(3,6,'manoj','k jayan','male','puliyangood',0,'7'),
(4,7,'manoj','bajpayae','male','puliyangood',0,'7'),
(11,14,'aswin','k','male','poochakad',8,'8'),
(13,17,'aswin','k','male','poochakad',9,'8'),
(14,19,'nimisha','k','female','anakaadi',9,'8'),
(15,20,' manoj','a','male','pasasdasdas',10,'8'),
(16,11,'prakash','ganga','male','cheemeni',11,'7');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `subject` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`subject_id`,`course_id`,`subject`) values 
(1,2,'bvdvbnbscdbm'),
(3,1,'asad'),
(5,8,'vara'),
(8,9,'Data Communication'),
(10,10,'Web Development'),
(11,10,'COA');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
