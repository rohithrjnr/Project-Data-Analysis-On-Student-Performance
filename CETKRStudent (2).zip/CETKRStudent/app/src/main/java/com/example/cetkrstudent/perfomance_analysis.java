package com.example.cetkrstudent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class perfomance_analysis extends AppCompatActivity {
    RadioButton r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22;
    TextView t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
    Button b1;
    SharedPreferences sh;
    String q1, q2, q3, q4, q5, q6, q7, q8, q9, q10,q11;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfomance_analysis);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        r1 = findViewById(R.id.radioButton10);
        r2 = findViewById(R.id.radioButton9);
        r2.setChecked(true);

        r3 = findViewById(R.id.radioButton11);
        r4 = findViewById(R.id.radioButton12);
        r4.setChecked(true);

        r5 = findViewById(R.id.radioButton13);
        r6 = findViewById(R.id.radioButton14);
        r6.setChecked(true);

        r7 = findViewById(R.id.radioButton15);
        r8 = findViewById(R.id.radioButton16);
        r8.setChecked(true);

        r9 = findViewById(R.id.radioButton18);
        r10 = findViewById(R.id.radioButton17);
        r10.setChecked(true);

        r11 = findViewById(R.id.radioButton19);
        r12 = findViewById(R.id.radioButton20);
        r12.setChecked(true);

        r13 = findViewById(R.id.radioButton22);
        r14 = findViewById(R.id.radioButton21);
        r14.setChecked(true);

        r15 = findViewById(R.id.radioButton4);
        r16 = findViewById(R.id.radioButton3);
        r16.setChecked(true);

        r17 = findViewById(R.id.radioButton6);
        r18 = findViewById(R.id.radioButton5);
        r18.setChecked(true);

        r19 = findViewById(R.id.radioButton8);
        r20 = findViewById(R.id.radioButton7);
        r20.setChecked(true);

        r21 = findViewById(R.id.radioButton);
        r22 = findViewById(R.id.radioButton2);
        r22.setChecked(true);

        b1 = findViewById(R.id.button10);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (r1.isChecked())
                {
                    q1="1";
                }
                else {
                    q1="0";
                }

                if (r3.isChecked())
                {
                    q2="1";
                }
                else
                {
                    q2="0";
                }
                if (r5.isChecked())
                {
                    q3="1";
                }
                else
                {
                    q3="0";
                }
                if (r7.isChecked())
                {
                    q4="1";
                }
                else
                {
                    q4="0";
                }
                if (r9.isChecked())
                {
                    q5="1";
                }
                else
                {
                    q5="0";
                }
                if (r11.isChecked())
                {
                    q6="1";
                }
                else
                {
                    q6="0";
                }
                if (r13.isChecked())
                {
                    q7="1";
                }
                else
                {
                    q7="0";
                }
                if (r15.isChecked())
                {
                    q8="1";
                }
                else
                {
                    q8="0";
                }
                if (r17.isChecked())
                {
                    q9="1";
                }
                else
                {
                    q9="0";
                }
                if (r19.isChecked())
                {
                    q10="1";
                }
                else
                {
                    q10="0";
                }
                if (r21.isChecked())
                {
                    q11="1";
                }
                else
                {
                    q11="0";
                }
                RequestQueue queue = Volley.newRequestQueue(perfomance_analysis.this);
                String url = "http://" + sh.getString("ip", "") + ":5000/perfomance";

                // Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the response string.
                        Log.d("+++++++++++++++++", response);
                        try {
                            JSONObject json = new JSONObject(response);
                            String res = json.getString("task");
                            String result = json.getString("result");

                            if (res.equalsIgnoreCase("success")) {
//
                                Intent ik = new Intent(getApplicationContext(), perfomancanalysis.class);
                                ik.putExtra("result",result);
                                startActivity(ik);

                            } else {

                                Toast.makeText(perfomance_analysis.this, "Invalid", Toast.LENGTH_SHORT).show();

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                        Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("q1", q1);
                        params.put("q2", q2);
                        params.put("q3", q3);
                        params.put("q4", q4);
                        params.put("q5", q5);
                        params.put("q6", q6);
                        params.put("q7", q7);
                        params.put("q8", q8);
                        params.put("q9", q9);
                        params.put("q10", q10);
                        params.put("q11", q11);
                        params.put("lid", sh.getString("lid", ""));


                        return params;
                    }
                };
                queue.add(stringRequest);
            }
        });

    }
}
